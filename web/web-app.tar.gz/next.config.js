/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  experimental: {
    appDir: true,
  },
  env: {
    CUSTOM_KEY: 'my-value',
  },
  images: {
    domains: ['89.117.60.144', 'localhost'],
  },
}

module.exports = nextConfig
