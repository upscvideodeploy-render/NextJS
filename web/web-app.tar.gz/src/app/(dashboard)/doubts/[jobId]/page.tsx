'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/supabase-js';

interface Job {
  id: string;
  job_type: string;
  priority: string;
  status: 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled';
  payload: {
    question: string;
    video_url?: string;
    thumbnail_url?: string;
    duration?: number;
  };
  queue_position: number | null;
  retry_count: number;
  error_message: string | null;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
}

export default function DoubtStatusPage() {
  const params = useParams();
  const router = useRouter();
  const jobId = params.jobId as string;
  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    loadJob();
    const interval = setInterval(loadJob, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, [jobId]);

  const loadJob = async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) {
        setError('Job not found');
        return;
      }

      setJob(data as Job);
      setLoading(false);
    } catch (err) {
      setError('Failed to load job status');
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-8 max-w-2xl text-center">
        <div className="animate-spin text-6xl mb-4">⏳</div>
        <p className="text-gray-400">Loading...</p>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="container mx-auto p-8 max-w-2xl text-center">
        <div className="text-6xl mb-4">❌</div>
        <h2 className="text-2xl font-bold mb-4">Job Not Found</h2>
        <p className="text-gray-400 mb-6">{error}</p>
        <button onClick={() => router.push('/dashboard/ask-doubt')} className="btn-primary">
          Submit Another Doubt
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-8 max-w-4xl">
      <h1 className="text-3xl font-bold mb-8">Video Generation Status</h1>

      {/* Status Card */}
      <div className="neon-glass p-8 rounded-2xl mb-8">
        {/* Question */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-400 mb-2">Your Question:</h3>
          <p className="text-lg text-white">{job.payload.question}</p>
        </div>

        {/* Status */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Status</h3>
            {getStatusBadge(job.status)}
          </div>

          {job.status === 'queued' && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-300">
                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <span className="text-sm">📋</span>
                </div>
                <div>
                  <p className="font-medium">In Queue</p>
                  <p className="text-sm text-gray-400">
                    Position: {job.queue_position || 'Calculating...'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {job.status === 'processing' && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-300">
                <div className="animate-spin text-2xl">⚙️</div>
                <div>
                  <p className="font-medium">Generating Video...</p>
                  <p className="text-sm text-gray-400">
                    This usually takes 2-5 minutes
                  </p>
                </div>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden">
                <div className="h-full bg-neon-blue rounded-full animate-pulse" style={{ width: '60%' }} />
              </div>
            </div>
          )}

          {job.status === 'completed' && job.payload.video_url && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-green-400">
                <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
                  <span className="text-lg">✅</span>
                </div>
                <p className="font-medium">Video Ready!</p>
              </div>

              {/* Video Player */}
              <div className="mt-6">
                <video
                  src={job.payload.video_url}
                  controls
                  poster={job.payload.thumbnail_url}
                  className="w-full rounded-lg"
                >
                  Your browser does not support the video tag.
                </video>
              </div>

              {/* Actions */}
              <div className="flex gap-4 mt-6">
                <button className="btn-secondary flex-1">
                  📥 Download
                </button>
                <button className="btn-secondary flex-1">
                  🔗 Share
                </button>
                <button onClick={() => router.push('/dashboard/ask-doubt')} className="btn-primary flex-1">
                  ➕ New Doubt
                </button>
              </div>
            </div>
          )}

          {job.status === 'failed' && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-red-400">
                <div className="w-8 h-8 bg-red-500/20 rounded-full flex items-center justify-center">
                  <span className="text-lg">❌</span>
                </div>
                <div>
                  <p className="font-medium">Generation Failed</p>
                  {job.retry_count > 0 && (
                    <p className="text-sm text-gray-400">
                      Retries: {job.retry_count}/3
                    </p>
                  )}
                </div>
              </div>
              {job.error_message && (
                <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg text-sm text-red-300">
                  {typeof job.error_message === 'string'
                    ? job.error_message
                    : 'An error occurred during video generation'}
                </div>
              )}
              <button onClick={() => router.push('/dashboard/ask-doubt')} className="btn-primary w-full">
                Try Again
              </button>
            </div>
          )}
        </div>

        {/* Metadata */}
        <div className="border-t border-white/10 pt-6 mt-6 grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-400">Job ID:</span>
            <p className="text-white font-mono">{job.id.slice(0, 13)}...</p>
          </div>
          <div>
            <span className="text-gray-400">Created:</span>
            <p className="text-white">{new Date(job.created_at).toLocaleString()}</p>
          </div>
          {job.completed_at && (
            <div>
              <span className="text-gray-400">Completed:</span>
              <p className="text-white">{new Date(job.completed_at).toLocaleString()}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function getStatusBadge(status: string) {
  const badges = {
    queued: '🔵 Queued',
    processing: '⚙️ Processing',
    completed: '✅ Completed',
    failed: '❌ Failed',
    cancelled: '⚫ Cancelled',
  };

  const colors = {
    queued: 'bg-blue-500/20 text-blue-400',
    processing: 'bg-yellow-500/20 text-yellow-400',
    completed: 'bg-green-500/20 text-green-400',
    failed: 'bg-red-500/20 text-red-400',
    cancelled: 'bg-gray-500/20 text-gray-400',
  };

  return (
    <span className={`px-4 py-2 rounded-full text-sm font-medium ${colors[status as keyof typeof colors]}`}>
      {badges[status as keyof typeof badges] || status}
    </span>
  );
}
